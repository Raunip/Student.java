package Student;

public class StudentTetser {
    public static void main(String[] args){
        Student s1 = new Student();  /** create a student s1 object */
        System.out.println(s1.StudentDataInput()); /** calls the StudnetDataInput method to
         print the string with student name, test count
         and grade average */
    }
}
